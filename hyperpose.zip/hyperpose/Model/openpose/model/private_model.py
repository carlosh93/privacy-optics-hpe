import tensorflow as tf
import tensorlayer as tl
import json
import numpy as np
from tensorlayer import layers
from tensorlayer.models import Model
from ..utils import tf_repeat
from ...optics.optics_layer import OpticsZernike
# import hyperpose.Model.optics.globals_vars as globals_vars
import globals as globals_var


def get_optics_layer(optics_cfg, optics_summary):
    with open(optics_cfg, 'r') as read_file:
        optics_cfg = json.load(read_file)
    tf_optics = OpticsZernike(summary=optics_summary, patch_size=optics_cfg["PATCH_SIZE"],
                              sensor_distance=optics_cfg["SENSOR_DISTANCE"],
                              refractive_idcs=np.array(optics_cfg["REFRACTIVE_IDCS"]),
                              wave_lengths=np.array(optics_cfg["WAVE_LENGTHS"]),
                              height_tolerance=optics_cfg["HEIGHT_TOLERANCE"],
                              wave_resolution=optics_cfg["WAVE_RESOLUTION"],
                              sample_interval=optics_cfg["SAMPLE_INTERVAL"],
                              upsample=optics_cfg["UPSAMPLE"]
                              )
    tf_optics.build(input_shape=[None, optics_cfg["PATCH_SIZE"], optics_cfg["PATCH_SIZE"], 3])
    optics_focus_weights = np.load('./pretrained_models/optics/optics_trained_weights_432x432.npz', allow_pickle=True)[
        'optics_trained_weights']

    # To initialize the model in order to use it in Tensorlayer
    _ = tf_optics(np.random.random((1, optics_cfg["PATCH_SIZE"], optics_cfg["PATCH_SIZE"], 3)).astype(np.float32))
    # Load pretrained weights
    # tf_optics.set_weights([np.concatenate([np.zeros(shape=(3, 1, 1)), optics_focus_weights], axis=0)])
    # optics_focus_weights[0] = optics_focus_weights[0] - 4.0

    # tf_optics.set_weights([optics_focus_weights[:247, :, :]])
    tf_optics.set_weights([optics_focus_weights])

    return tf_optics


class Private_OpenPose(Model):
    def __init__(self, optics_config_file_path, pose_model, config):
        super(Private_OpenPose, self).__init__()
        summary_path = config.log.tensorboard_train_path
        if pose_model.name == "lightweightopenpose":
            self.last_tuned_layer = 68  # 16  # 52  # 68
            print("tune first {} layers".format(self.last_tuned_layer))
        if pose_model.name == 'openpose':
            self.last_tuned_layer = 21  # 20  # 60
            print("tune first {} layers".format(self.last_tuned_layer))
        if summary_path is not None:
            self.model_summary = tf.summary.create_file_writer(summary_path)
        else:
            self.model_summary = None
        self.initialize_global_vars()
        tf_optics = get_optics_layer(optics_config_file_path, self.model_summary)
        self.optics_layer = tl.layers.Lambda(tf_optics, tf_optics.trainable_variables, name="optics_layer")
        self.pose_model = pose_model
        self.pose_model.load_weights(config.train.pretrained_model)

    @tf.function
    def forward(self, x, is_train=False):
        self.is_train = is_train
        sq_size = max(self.pose_model.hin, self.pose_model.win)
        x = tf.image.resize(x, [sq_size, sq_size])
        x_sensor = self.optics_layer.forward(x)
        x_sensor = tf.image.resize(x_sensor, [self.pose_model.hin, self.pose_model.win])
        return x_sensor, self.pose_model.forward(x_sensor, is_train)

    def infer(self, x):
        """
        # Low Res
        sq_size = max(self.pose_model.hin, self.pose_model.win)
        x = tf.image.resize(x, [sq_size, sq_size])
        x_sensor = self.optics_layer.forward(x)
        # ===
        x_sensor = tf.image.resize(x_sensor, [25, 25])
        # ===
        x_sensor = tf.image.resize(x_sensor, [self.pose_model.hin, self.pose_model.win])
        return x_sensor, self.pose_model.forward(x_sensor, is_train=False)
        """
        # Proposed
        sq_size = max(self.pose_model.hin, self.pose_model.win)
        x = tf.image.resize(x, [sq_size, sq_size])
        x_sensor = self.optics_layer.forward(x)
        x_sensor = tf.image.resize(x_sensor, [self.pose_model.hin, self.pose_model.win])
        return x_sensor, self.pose_model.forward(x_sensor, is_train=False)

    def cal_split_loss(self, gt_conf, gt_paf, mask, stage_confs, stage_pafs):
        stage_losses_face, stage_losses_body = [], []
        batch_size = gt_conf.shape[0]
        if self.pose_model.concat_dim == 1:
            mask_conf = tf_repeat(mask, [1, self.pose_model.n_confmaps, 1, 1])
            mask_paf = tf_repeat(mask, [1, self.pose_model.n_pafmaps, 1, 1])
        elif self.pose_model.concat_dim == -1:
            mask_conf = tf_repeat(mask, [1, 1, 1, self.pose_model.n_confmaps])
            mask_paf = tf_repeat(mask, [1, 1, 1, self.pose_model.n_pafmaps])

        loss_confs_face, loss_confs_body, loss_pafs_face, loss_pafs_body = [], [], [], []
        # face_idx = [14, 15, 16,17] #
        # face_paf_idx = [30, 31, 32, 33, 34, 35, 36, 37]
        gt_conf_face = gt_conf[..., 14:18]
        gt_conf_body = tf.concat([gt_conf[..., :14], tf.expand_dims(gt_conf[..., -1], axis=-1)], axis=-1)
        mask_conf_face = mask_conf[..., 14:18]
        mask_conf_body = tf.concat([mask_conf[..., :14], tf.expand_dims(mask_conf[..., -1], axis=-1)], axis=-1)
        gt_paf_face = gt_paf[..., 30:38]
        gt_paf_body = gt_paf[..., :30]
        mask_paf_face = mask_paf[..., 30:38]
        mask_paf_body = mask_paf[..., :30]
        for stage_conf, stage_paf in zip(stage_confs, stage_pafs):
            st_conf_face = stage_conf[..., 14:18]
            st_conf_body = tf.concat([stage_conf[..., :14], tf.expand_dims(stage_conf[..., -1], axis=-1)], axis=-1)
            st_paf_face = stage_paf[..., 30:38]
            st_paf_body = stage_paf[..., :30]
            loss_conf_face = tf.nn.l2_loss((gt_conf_face - st_conf_face) * mask_conf_face)
            loss_conf_body = tf.nn.l2_loss((gt_conf_body - st_conf_body) * mask_conf_body)
            loss_paf_face = tf.nn.l2_loss((gt_paf_face - st_paf_face) * mask_paf_face)
            loss_paf_body = tf.nn.l2_loss((gt_paf_body - st_paf_body) * mask_paf_body)
            stage_losses_face.append(loss_conf_face)
            stage_losses_face.append(loss_paf_face)
            stage_losses_body.append(loss_conf_body)
            stage_losses_body.append(loss_paf_body)
            loss_confs_face.append(loss_conf_face)
            loss_confs_body.append(loss_conf_body)
            loss_pafs_face.append(loss_paf_face)
            loss_pafs_body.append(loss_paf_body)
        pd_loss_face = tf.reduce_mean(stage_losses_face) / batch_size
        pd_loss_body = tf.reduce_mean(stage_losses_body) / batch_size
        return pd_loss_face, pd_loss_body, loss_confs_face, loss_confs_body, loss_pafs_face, loss_pafs_body

    @staticmethod
    def cal_optics_loss(y_true, y_pred, margin=10):
        # y_true = tf.transpose(y_true, [0, 2, 3, 1])
        # y_pred = tf.transpose(y_pred, [0, 2, 3, 1])
        ground_truth = tf.cast(y_true, tf.float32)
        model_output = tf.cast(y_pred, tf.float32)

        """
        # For Cross Entroy
        ground_truth = ground_truth[:, margin:-margin, margin:-margin, :]
        model_output = model_output[:, margin:-margin, margin:-margin, :]

        ground_truth = tf.reshape(ground_truth, [-1])
        model_output = tf.reshape(model_output, [-1])
        """
        # loss = tf.reduce_mean(tf.square(model_output - ground_truth))
        # loss = tf.reduce_mean(tf.square(model_output - ground_truth)[:, margin:-margin, margin:-margin, :])
        loss = tf.math.sqrt(tf.nn.l2_loss((model_output - ground_truth)[:, margin:-margin, margin:-margin, :]))  # Sqrt
        # loss = tf.math.tanh(tf.nn.l2_loss((model_output - ground_truth)[:, margin:-margin, margin:-margin, :])) # Tanh
        # loss = tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(ground_truth, model_output)) # CrossEntropy
        return loss

    @staticmethod
    def initialize_global_vars():
        globals_var.TFStep = -1
        globals_var.stopUtilsSummary = False
        globals_var.TF_log_interval = -1
