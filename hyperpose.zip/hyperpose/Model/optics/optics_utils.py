import tensorflow as tf
import numpy as np
import abc
from numpy.fft import ifftshift
# import hyperpose.Model.optics.globals_vars as globals_vars
import globals as globals_vars
import poppy
import matplotlib.pyplot as plt


##############################
# Helper functions
##############################


def get_zernike_volume(resolution, n_terms, scale_factor=1e-6):
    zernike_volume = poppy.zernike.zernike_basis(nterms=n_terms, npix=resolution, outside=0.0)
    return zernike_volume * scale_factor


def save_images_to_file(name, var):
    img_var = var - tf.reduce_min(var)
    img_var = img_var / tf.reduce_max(img_var)
    img_var = tf.cast(img_var * 255, dtype=tf.uint8)
    tf_image = tf.image.encode_png(img_var[0])
    tf.io.write_file(globals_vars.save_path + name + "_" + tf.strings.as_string(globals_vars.TFStep) + ".png", tf_image)


def attach_summaries(name, var, image=False, log_image=False, summary=None, only_scalar=False):
    if summary is not None and globals_vars.TFStep > 0 and (not globals_vars.stopUtilsSummary) \
            and (globals_vars.TFStep % globals_vars.TF_log_interval == 0 or globals_vars.TFStep == 2):
        with summary.as_default():
            summary_step = tf.cast(globals_vars.TFStep, tf.int64)
            if only_scalar:
                tf.summary.scalar(name, var, step=summary_step)
            else:
                if image:
                    tf.summary.image(name, var / tf.reduce_max(var), max_outputs=3, step=summary_step)
                    save_images_to_file(name, var)
                if log_image and image:
                    tmp = tf.math.log(var + 1e-12)
                    tmp -= tf.reduce_mean(tmp)
                    tf.summary.image(name + '_log', tmp / tf.reduce_max(tmp), max_outputs=3, step=summary_step)
                    save_images_to_file(name + '_log', tmp)
                tf.summary.scalar(name + '_mean', tf.reduce_mean(var), step=summary_step)
                tf.summary.scalar(name + '_max', tf.reduce_max(var), step=summary_step)
                tf.summary.scalar(name + '_min', tf.reduce_min(var), step=summary_step)
                tf.summary.histogram(name + '_histogram', var, step=summary_step)


def transp_fft2d(a_tensor, dtype=tf.complex64):
    """Takes images of shape [batch_size, x, y, channels] and transposes them
    correctly for tensorflows fft2d to work.
    """
    # Tensorflow's fft only supports complex64 dtype
    a_tensor = tf.cast(a_tensor, tf.complex64)
    # Tensorflow's FFT operates on the two innermost (last two!) dimensions
    a_tensor_transp = tf.transpose(a_tensor, [0, 3, 1, 2])
    a_fft2d = tf.signal.fft2d(a_tensor_transp)
    a_fft2d = tf.cast(a_fft2d, dtype)
    a_fft2d = tf.transpose(a_fft2d, [0, 2, 3, 1])
    return a_fft2d


def load_optics_config(cfg):

    optics_cfg = {
        "sensor_distance": cfg["SENSOR_DISTANCE"],
        "refractive_idcs": np.array(cfg["REFRACTIVE_IDCS"]),
        "wave_lengths": np.array(cfg["WAVE_LENGTHS"]),
        "height_tolerance": cfg["HEIGHT_TOLERANCE"],
        "wave_resolution": cfg["WAVE_RESOLUTION"],
        "patch_size": cfg["PATCH_SIZE"],
        "sample_interval": cfg["SAMPLE_INTERVAL"],
        "upsample": cfg["UPSAMPLE"],
        "init_gamma": cfg["INIT_GAMMA"]
    }

    return optics_cfg


def inverse_filter(blurred, estimate, psf, gamma):
    """ Inverse filtering in the frequency domain.

    Args:
        blurred: image with shape (batch_size, height, width, num_img_channels)
        estimate: image with shape (batch_size, height, width, num_img_channels)
        psf: filters with shape (kernel_height, kernel_width, num_img_channels, num_filters)
        gamma: Optimization variable that determines regularization (higher --> more regularization, output is closer to
               "estimate", lower --> less regularization, output is closer to straight inverse filtered-result).
               :param self:
    """
    img_shape = blurred.shape.as_list()
    a_tensor_transp = tf.transpose(blurred, [0, 3, 1, 2])
    estimate_transp = tf.transpose(estimate, [0, 3, 1, 2])

    # Everything has shape (batch_size, num_channels, height, width)
    img_fft = tf.signal.fft2d(tf.complex(a_tensor_transp, 0.))
    otf = psf2otf(psf, output_size=img_shape[1:3])
    otf = tf.transpose(otf, [2, 3, 0, 1])

    adj_conv = img_fft * tf.math.conj(otf)

    # This is a slight modification to standard inverse filtering - gamma not only regularizes the inverse filtering,
    # but also trades off between the regularized inverse filter and the unfiltered estimate_transp.
    numerator = adj_conv + tf.signal.fft2d(tf.complex(gamma * estimate_transp, 0.))

    kernel_mags = tf.square(tf.abs(otf))  # Magnitudes of the blur kernel.

    denominator = tf.complex(kernel_mags + gamma, 0.0)
    filtered = tf.divide(numerator, denominator)
    cplx_result = tf.signal.ifft2d(filtered)
    real_result = tf.math.real(cplx_result)  # Discard complex parts.

    # Get back to (batch_size, num_channels, height, width)
    result = tf.transpose(real_result, [0, 2, 3, 1])
    return result


def transp_ifft2d(a_tensor, dtype=tf.complex64):
    a_tensor = tf.transpose(a_tensor, [0, 3, 1, 2])
    a_tensor = tf.cast(a_tensor, tf.complex64)
    a_ifft2d_transp = tf.signal.ifft2d(a_tensor)
    # Transpose back to [batch_size, x, y, channels]
    a_ifft2d = tf.transpose(a_ifft2d_transp, [0, 2, 3, 1])
    a_ifft2d = tf.cast(a_ifft2d, dtype)
    return a_ifft2d


def phaseshifts_from_height_map(height_map, wave_lengths, refractive_idcs):
    '''Calculates the phase shifts created by a height map with certain
    refractive index for light with specific wave length.
    '''
    # refractive index difference
    delta_N = refractive_idcs.reshape([1, 1, 1, -1]) - 1.
    # wave number
    wave_nos = 2. * np.pi / wave_lengths
    wave_nos = wave_nos.reshape([1, 1, 1, -1])
    # phase delay indiced by height field
    phi = wave_nos * delta_N * height_map
    phase_shifts = compl_exp_tf(phi)
    return phase_shifts


def compl_exp_tf(phase, dtype=tf.complex64, name='complex_exp'):
    """Complex exponent via euler's formula, since Cuda doesn't have a GPU kernel for that.
    Casts to *dtype*.
    """
    phase = tf.cast(phase, tf.float64)
    return tf.add(tf.cast(tf.cos(phase), dtype=dtype),
                  1.j * tf.cast(tf.sin(phase), dtype=dtype),
                  name=name)


def height_map_element(input_field,
                       height_map_var,
                       height_map_shape,
                       wave_lengths,
                       refractive_idcs,
                       height_tolerance=None,  # Default height tolerance is 2 nm.
                       summary=None
                       ):
    height_map_full = tf.image.resize(height_map_var, height_map_shape[1:3],
                                      method=tf.image.ResizeMethod.NEAREST_NEIGHBOR)
    height_map = tf.square(height_map_full, name='height_map')

    attach_summaries("Height_map", height_map, image=True, log_image=True, summary=summary)

    element = PhasePlate(wave_lengths=wave_lengths,
                         height_map=height_map,
                         refractive_idcs=refractive_idcs,
                         height_tolerance=height_tolerance)

    return element(input_field)


def get_intensities(input_field):
    return tf.square(tf.abs(input_field), name='intensities')


def gaussian_noise(image, img_shape, stddev=0.001):
    dtype = image.dtype
    return image + tf.random.normal(img_shape, 0.0, stddev, dtype=dtype)


def circular_aperture(input_field):
    input_shape = input_field.shape.as_list()
    [x, y] = np.mgrid[-input_shape[1] // 2: input_shape[1] // 2, -input_shape[2] // 2: input_shape[2] // 2].astype(
        np.float64)

    max_val = np.amax(x)

    r = np.sqrt(x ** 2 + y ** 2)[None, :, :, None]
    aperture = (r < max_val).astype(np.float64)
    return aperture * input_field


def propagate_fresnel(input_field,
                      distance,
                      sampling_interval,
                      wave_lengths):
    input_shape = input_field.shape.as_list()
    propagation = FresnelPropagation(input_shape,
                                     distance=distance,
                                     discretization_size=sampling_interval,
                                     wave_lengths=wave_lengths)
    return propagation(input_field)


def ifftshift2d_tf(a_tensor):
    input_shape = a_tensor.shape.as_list()

    new_tensor = a_tensor
    for axis in range(1, 3):
        n = input_shape[axis]
        split = n - (n + 1) // 2
        mylist = np.concatenate((np.arange(split, n), np.arange(split)))
        new_tensor = tf.gather(new_tensor, mylist, axis=axis)
    return new_tensor


def psf2otf(input_filter, output_size):
    """Convert 4D tensorflow filter into its FFT.

    :param input_filter: PSF. Shape (height, width, num_color_channels, num_color_channels)
    :param output_size: Size of the output OTF.
    :return: The otf.
    """
    # pad out to output_size with zeros
    # circularly shift so center pixel is at 0,0
    fh, fw, _, _ = input_filter.shape.as_list()

    if output_size[0] != fh:
        pad = (output_size[0] - fh) / 2

        if (output_size[0] - fh) % 2 != 0:
            pad_top = pad_left = int(np.ceil(pad))
            pad_bottom = pad_right = int(np.floor(pad))
        else:
            pad_top = pad_left = int(pad) + 1
            pad_bottom = pad_right = int(pad) - 1

        padded = tf.pad(input_filter, [[pad_top, pad_bottom],
                                       [pad_left, pad_right], [0, 0], [0, 0]], "CONSTANT")
    else:
        padded = input_filter

    padded = tf.transpose(padded, [2, 0, 1, 3])
    padded = ifftshift2d_tf(padded)
    padded = tf.transpose(padded, [1, 2, 0, 3])

    # Take FFT
    tmp = tf.transpose(padded, [2, 3, 0, 1])
    tmp = tf.signal.fft2d(tf.complex(tmp, 0.))
    return tf.transpose(tmp, [2, 3, 0, 1])


def img_psf_conv(img, psf, otf=None, adjoint=False, circular=False):
    """Performs a convolution of an image and a psf in frequency space.

    :param img: Image tensor.
    :param psf: PSF tensor.
    :param otf: If OTF is already computed, the otf.
    :param adjoint: Whether to perform an adjoint convolution or not.
    :param circular: Whether to perform a circular convolution or not.
    :return: Image convolved with PSF.
    """
    img = tf.convert_to_tensor(img, dtype=tf.float32)
    psf = tf.convert_to_tensor(psf, dtype=tf.float32)

    img_shape = img.shape.as_list()
    pad_top = pad_bottom = pad_left = pad_right = 0
    if not circular:
        target_side_length = 2 * img_shape[1]

        height_pad = (target_side_length - img_shape[1]) / 2
        width_pad = (target_side_length - img_shape[1]) / 2

        pad_top, pad_bottom = int(np.ceil(height_pad)), int(np.floor(height_pad))
        pad_left, pad_right = int(np.ceil(width_pad)), int(np.floor(width_pad))

        img = tf.pad(img, [[0, 0], [pad_top, pad_bottom], [pad_left, pad_right], [0, 0]], "CONSTANT")
        img_shape = img.shape.as_list()

    img_fft = transp_fft2d(img)

    if otf is None:
        otf = psf2otf(psf, output_size=img_shape[1:3])
        otf = tf.transpose(otf, [2, 0, 1, 3])

    otf = tf.cast(otf, tf.complex64)
    img_fft = tf.cast(img_fft, tf.complex64)

    if adjoint:
        result = transp_ifft2d(img_fft * tf.math.conj(otf))
    else:
        result = transp_ifft2d(img_fft * otf)

    result = tf.cast(tf.math.real(result), tf.float32)

    if not circular:
        result = result[:, pad_top:-pad_bottom, pad_left:-pad_right, :]

    return result


def least_common_multiple(a, b):
    return abs(a * b) / np.math.gcd(a, b) if a and b else 0


def area_downsampling_tf(input_image, target_side_length):
    input_shape = input_image.shape.as_list()
    input_image = tf.cast(input_image, tf.float32)

    if not input_shape[1] % target_side_length:
        factor = int(input_shape[1] / target_side_length)
        output_img = tf.nn.avg_pool(input_image,
                                    [1, factor, factor, 1],
                                    strides=[1, factor, factor, 1],
                                    padding="VALID")
    else:
        # We upsample the image and then average pool
        lcm_factor = least_common_multiple(target_side_length, input_shape[1]) / target_side_length

        if lcm_factor > 10:
            print(
                "Warning: area downsampling is very expensive and not precise if source and target wave length have a "
                "large least common multiple")
            upsample_factor = 10
        else:
            upsample_factor = int(lcm_factor)
        img_upsampled = tf.image.resize(input_image, size=2 * [upsample_factor * target_side_length])
        # img_upsampled = tf.image.resize_nearest_neighbor(input_image,
        #                                                size=2 * [upsample_factor * target_side_length])
        output_img = tf.nn.avg_pool(img_upsampled,
                                    [1, upsample_factor, upsample_factor, 1],
                                    strides=[1, upsample_factor, upsample_factor, 1],
                                    padding="VALID")

    return output_img


def get_psf_from_zernike_coeffs(zernike_coeffs, zernike_volume, optics_cfg, input_img=None):
    wave_res = optics_cfg['wave_resolution']
    wave_lengths = optics_cfg['wave_lengths']
    refractive_idcs = optics_cfg['refractive_idcs']
    height_tolerance = optics_cfg['height_tolerance']
    sensor_distance = optics_cfg['sensor_distance']
    sample_interval = optics_cfg['sample_interval']
    upsample = optics_cfg['upsample']
    patch_size = optics_cfg['patch_size']

    physical_size = float(wave_res[0] * sample_interval)

    num_zernike_coeffs = zernike_coeffs.shape[0]
    height_map = tf.reduce_sum(zernike_coeffs * zernike_volume, axis=0)
    height_map = tf.expand_dims(tf.expand_dims(height_map, 0), -1, name='height_map')

    element = PhasePlate(wave_lengths=wave_lengths,
                         height_map=height_map,
                         refractive_idcs=refractive_idcs,
                         height_tolerance=height_tolerance)

    N, M = wave_res
    [x, y] = np.mgrid[-N // 2:N // 2, -M // 2:M // 2].astype(np.float64)

    x = x / N * physical_size
    y = y / M * physical_size

    squared_sum = x ** 2 + y ** 2

    wave_nos = 2. * np.pi / wave_lengths
    wave_nos = wave_nos.reshape([1, 1, 1, -1])
    # [1 / 2, 1 / 1.5, 1 / 1, 1 / 0.5, 1000]
    depth = 1 / 2  # self.sensor_distance  # 0: infty, 0.5: 2m, 1: 1m, 1.5: 0.67m, 2: 0.5m (diopters-meters)
    curvature = tf.sqrt(squared_sum + tf.cast(depth, tf.float64) ** 2)  # tf.cast(self.distance, tf.float64) ** 2
    curvature = tf.expand_dims(tf.expand_dims(curvature, 0), -1)

    spherical_wavefront = compl_exp_tf(wave_nos * curvature, dtype=tf.complex64)

    field = element(spherical_wavefront)
    field = circular_aperture(field)
    sensor_incident_field = propagate_fresnel(field,
                                              distance=sensor_distance,
                                              sampling_interval=sample_interval,
                                              wave_lengths=wave_lengths)
    psf = get_intensities(sensor_incident_field)

    if not upsample:
        psf = area_downsampling_tf(psf, patch_size)

    psf = tf.divide(psf, tf.reduce_sum(psf, axis=[1, 2], keepdims=True))

    if input_img is not None:
        # Image formation: PSF is convolved with input image
        psfs = tf.transpose(psf, [1, 2, 0, 3])

        # ------------------------------------
        # Get Sensor Image
        # ------------------------------------
        # Upsample input_img to match wave resolution.
        if upsample:
            input_img = tf.image.resize(input_img, wave_res,
                                        method=tf.image.ResizeMethod.NEAREST_NEIGHBOR)

        sensor_img = img_psf_conv(input_img, psfs)
        if upsample:
            sensor_img = area_downsampling_tf(sensor_img, patch_size)

        noise_sigma = tf.random.uniform(minval=0.001, maxval=0.02, shape=[])

        noisy_img = gaussian_noise(sensor_img,
                                   [patch_size, patch_size, input_img.shape[-1]],
                                   noise_sigma)

        output_image = tf.cast(sensor_img, tf.float32)

        return psf, output_image
    else:
        return psf

# Classes Definition


class Propagation(abc.ABC):
    def __init__(self,
                 input_shape,
                 distance,
                 discretization_size,
                 wave_lengths):
        self.input_shape = input_shape
        self.distance = distance
        self.wave_lengths = wave_lengths
        self.wave_nos = 2. * np.pi / wave_lengths
        self.discretization_size = discretization_size

    @abc.abstractmethod
    def _propagate(self, input_field):
        """Propagate an input field through the medium
        """

    def __call__(self, input_field):
        return self._propagate(input_field)


class FresnelPropagation(Propagation):
    def _propagate(self, input_field):
        _, M_orig, N_orig, _ = self.input_shape
        # zero padding.
        Mpad = M_orig // 4
        Npad = N_orig // 4
        M = M_orig + 2 * Mpad
        N = N_orig + 2 * Npad
        padded_input_field = tf.pad(input_field,
                                    [[0, 0], [Mpad, Mpad], [Npad, Npad], [0, 0]])

        [x, y] = np.mgrid[-N // 2:N // 2,
                 -M // 2:M // 2]

        # Spatial frequency
        fx = x / (self.discretization_size * N)  # max frequency = 1/(2*pixel_size)
        fy = y / (self.discretization_size * M)

        # We need to ifftshift fx and fy here, because ifftshift doesn't exist in TF.
        fx = ifftshift(fx)
        fy = ifftshift(fy)

        fx = fx[None, :, :, None]
        fy = fy[None, :, :, None]

        squared_sum = np.square(fx) + np.square(fy)

        # We create a non-trainable variable so that this computation can be reused
        # from call to call.
        if tf.is_tensor(self.distance):
            tmp = np.float64(self.wave_lengths * np.pi * -1. * squared_sum)
            constant_exp_part_init = tf.constant_initializer(tmp)
            constant_exponent_part = tf.Variable(name="Fresnel_kernel_constant_exponent_part",
                                                 initial_value=constant_exp_part_init,
                                                 shape=padded_input_field.shape,
                                                 dtype=tf.float64,
                                                 trainable=False)

            H = compl_exp_tf(self.distance * constant_exponent_part, dtype=tf.complex64,
                             name='fresnel_kernel')
        else:  # Save some memory
            tmp = np.float64(self.wave_lengths * np.pi * -1. * squared_sum * self.distance)
            # constant_exp_part_init = tf.constant_initializer(tmp)
            # constant_exponent_part = tf.Variable(name="Fresnel_kernel_constant_exponent_part",
            #                                      initial_value=constant_exp_part_init,
            #                                      shape=padded_input_field.shape,
            #                                      dtype=tf.float64,
            #                                      trainable=False)
            expo_part = tf.cast(tmp, tf.float64)
            H = compl_exp_tf(expo_part, dtype=tf.complex64,
                             name='fresnel_kernel')

        objFT = transp_fft2d(padded_input_field)
        out_field = transp_ifft2d(objFT * H)

        return out_field[:, Mpad:-Mpad, Npad:-Npad, :]


class PhasePlate:
    def __init__(self,
                 wave_lengths,
                 height_map,
                 refractive_idcs,
                 height_tolerance=None,
                 lateral_tolerance=None):
        self.wave_lengths = wave_lengths
        self.height_map = height_map
        self.refractive_idcs = refractive_idcs
        self.height_tolerance = height_tolerance
        self.lateral_tolerance = lateral_tolerance

        self._build()

    def _build(self):
        # Add manufacturing tolerances in the form of height map noise
        if self.height_tolerance is not None:
            self.height_map += tf.random.uniform(shape=self.height_map.shape,
                                                 minval=-self.height_tolerance,
                                                 maxval=self.height_tolerance,
                                                 dtype=self.height_map.dtype)
            # print("Phase plate with manufacturing tolerance %0.2e" % self.height_tolerance)

        self.phase_shifts = phaseshifts_from_height_map(self.height_map,
                                                        self.wave_lengths,
                                                        self.refractive_idcs)

    def __call__(self, input_field):
        input_field = tf.cast(input_field, tf.complex64)
        return tf.multiply(input_field, self.phase_shifts, name='phase_plate_shift')
