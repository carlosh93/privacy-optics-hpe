import tensorflow as tf
from . import optics_utils as utils
import numpy as np
import os


class OpticsZernike(tf.keras.layers.Layer):
    # refract [1.499, 1.493, 1.488]
    # sample_interval=3.69e-6
    # 1998
    def __init__(self, summary=None, sensor_distance=25e-3, refractive_idcs=np.array([1.4648, 1.4599, 1.4568]),
                 wave_lengths=np.array([460, 550, 640]) * 1e-9, height_tolerance=20e-9, wave_resolution=(736, 736),
                 patch_size=368, hm_reg_scale=1000.0, block_size=1, sample_interval=2e-6, height_map_initializer=None,
                 upsample=False, **kwargs):
        super(OpticsZernike, self).__init__(**kwargs)
        # self.output_dim = output_dim
        self.sensor_distance = sensor_distance  # Distance of sensor to aperture
        self.height_tolerance = height_tolerance  # manufacturing error
        self.hm_reg_scale = hm_reg_scale
        self.upsample = upsample
        self.patch_size = patch_size  # Size of patches to be extracted from images, and resolution of simulated sensor
        self.wave_lengths = wave_lengths  # Wave lengths to be modeled and optimized for
        self.sample_interval = sample_interval  # Sampling interval (size of one "pixel" in the simulated wavefront)
        self.refractive_idcs = refractive_idcs  # Refractive idcs of the phaseplate
        if wave_resolution is None:
            self.wave_res = [patch_size * 4, patch_size * 4]
        else:
            self.wave_res = wave_resolution

        self.block_size = block_size
        self.height_map_initializer = height_map_initializer

        self.physical_size = float(self.wave_res[0] * self.sample_interval)
        print("Physical size is %0.2e.\nWave resolution is %d." % (self.physical_size, self.wave_res[0]))

        # Declare Zernike Volume
        self.zernike_volume = None
        # Summary Writer
        self.writer = summary

        # Variables Declarations
        self.zernike_coeffs_no_train = None
        self.zernike_coeffs_train = None
        self.height_map = None
        self.channels = None

    def build(self, input_shape):

        self.channels = input_shape[-1]

        if not os.path.exists('zernike_volumes/zernike_volume_%d.npy' % self.wave_res[0]):
            self.zernike_volume = utils.get_zernike_volume(resolution=self.wave_res[0], n_terms=350).astype(np.float32)
            os.makedirs('zernike_volumes', exist_ok=True)
            np.save('zernike_volumes/zernike_volume_%d.npy' % self.wave_res[0], self.zernike_volume)
        else:
            self.zernike_volume = np.load('zernike_volumes/zernike_volume_%d.npy' % self.wave_res[0])

        self.zernike_volume = tf.convert_to_tensor(self.zernike_volume)
        num_zernike_coeffs = self.zernike_volume.shape.as_list()[0]

        zernike_inits = np.zeros((num_zernike_coeffs, 1, 1))
        zernike_inits[3] = -25  # This sets the defocus value to approximately focus the image for a distance of 1m.
        # zernike_initializer = tf.constant_initializer(zernike_inits)
        zernike_initializer = tf.constant_initializer(zernike_inits[3:, ...])
        self.zernike_coeffs_no_train = tf.constant(zernike_inits[:3, ...], dtype=tf.float32)

        self.zernike_coeffs_train = self.add_weight(name='zernike_coeffs',
                                                    shape=[num_zernike_coeffs - 3, 1, 1], # shape=[num_zernike_coeffs, 1, 1],
                                                    dtype=tf.float32,
                                                    trainable=True,
                                                    initializer=zernike_initializer)

        if self.upsample:
            print("Images will be upsampled to wave resolution")

    def call(self, input_img, **kwargs):

        # ------------------------------------
        # Build height map
        # ------------------------------------
        num_zernike_coeffs = self.zernike_volume.shape.as_list()[0]
        # zernike_coeffs_concat = self.zernike_coeffs_train
        zernike_coeffs_concat = tf.concat([self.zernike_coeffs_no_train, self.zernike_coeffs_train], axis=0)
        for i in range(num_zernike_coeffs):
            utils.attach_summaries(name='zernike_coeff_%d' % i,
                                   var=tf.squeeze(zernike_coeffs_concat[i, :, :]),
                                   summary=self.writer,
                                   only_scalar=True)

        self.height_map = tf.reduce_sum(zernike_coeffs_concat * self.zernike_volume, axis=0)
        self.height_map = tf.expand_dims(tf.expand_dims(self.height_map, 0), -1, name='height_map')

        utils.attach_summaries("Height_map", self.height_map, image=True, log_image=False, summary=self.writer)

        element = utils.PhasePlate(wave_lengths=self.wave_lengths,
                                   height_map=self.height_map,
                                   refractive_idcs=self.refractive_idcs,
                                   height_tolerance=self.height_tolerance)

        # ------------------------------------
        # Get PSF
        # ------------------------------------

        N, M = self.wave_res
        [x, y] = np.mgrid[-N // 2:N // 2,
                 -M // 2:M // 2].astype(np.float64)

        x = x / N * self.physical_size
        y = y / M * self.physical_size

        squared_sum = x ** 2 + y ** 2

        wave_nos = 2. * np.pi / self.wave_lengths
        wave_nos = wave_nos.reshape([1, 1, 1, -1])
        # [1 / 2, 1 / 1.5, 1 / 1, 1 / 0.5, 1000]
        depth = 1/2  # self.sensor_distance  # 0: infty, 0.5: 2m, 1: 1m, 1.5: 0.67m, 2: 0.5m (diopters-meters)
        curvature = tf.sqrt(squared_sum + tf.cast(depth, tf.float64) ** 2)  # tf.cast(self.distance, tf.float64) ** 2
        curvature = tf.expand_dims(tf.expand_dims(curvature, 0), -1)

        spherical_wavefront = utils.compl_exp_tf(wave_nos * curvature, dtype=tf.complex64)

        field = element(spherical_wavefront)
        field = utils.circular_aperture(field)
        sensor_incident_field = utils.propagate_fresnel(field,
                                                        distance=self.sensor_distance,
                                                        sampling_interval=self.sample_interval,
                                                        wave_lengths=self.wave_lengths)
        psf = utils.get_intensities(sensor_incident_field)

        if not self.upsample:
            psf = utils.area_downsampling_tf(psf, self.patch_size)

        psf = tf.divide(psf, tf.reduce_sum(psf, axis=[1, 2], keepdims=True))
        utils.attach_summaries('PSF', psf, image=True, log_image=True, summary=self.writer)

        # Image formation: PSF is convolved with input image
        psfs = tf.transpose(psf, [1, 2, 0, 3])

        # ------------------------------------
        # Get Sensor Image
        # ------------------------------------
        # Upsample input_img to match wave resolution.
        if self.upsample:
            input_img = tf.image.resize(input_img, self.wave_res,
                                        method=tf.image.ResizeMethod.NEAREST_NEIGHBOR)

        sensor_img = utils.img_psf_conv(input_img, psfs)
        if self.upsample:
            sensor_img = utils.area_downsampling_tf(sensor_img, self.patch_size)

        noise_sigma = tf.random.uniform(minval=0.001, maxval=0.02, shape=[])

        noisy_img = utils.gaussian_noise(sensor_img,
                                         [self.patch_size, self.patch_size, self.channels],
                                         noise_sigma)

        utils.attach_summaries('Sensor_img', noisy_img, image=True,
                               log_image=False, summary=self.writer)

        output_image = tf.cast(sensor_img, tf.float32)

        return output_image
