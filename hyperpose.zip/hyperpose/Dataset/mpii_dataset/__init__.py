from .dataset import init_dataset
from .dataset import MPII_dataset